const D = "https://daftar.tibh-esm.workers.dev", V = "1";
let busy = false;
function badge(t, c) { try { chrome.action.setBadgeText({ text: t }); if (c) chrome.action.setBadgeBackgroundColor({ color: c }); } catch (e) { } }
async function run() {
  if (busy) return; busy = true;
  try {
    for (let i = 0; i < 12; i++) {
      const r = await fetch(D + "/api/zrelay/next?v=" + V, { credentials: "include", cache: "no-store" });
      if (!r.ok) { badge("!", "#c2410c"); break; }
      const j = await r.json(); if (!j.job) { badge("", null); break; }
      const job = j.job; let st = 0, tx = "";
      if (!/^https:\/\/gw-fatoora\.zatca\.gov\.sa\//.test(job.url)) { tx = "blocked url"; }
      else {
        try { const z = await fetch(job.url, { method: "POST", headers: job.headers, body: job.body, credentials: "omit" }); st = z.status; tx = await z.text(); }
        catch (e) { tx = "network: " + (e && e.message || e); }
      }
      await fetch(D + "/api/zrelay/done?v=" + V, { method: "POST", credentials: "include", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id: job.id, status: st, text: tx.slice(0, 20000) }) });
      badge("✓", "#15803d");
    }
  } catch (e) { badge("!", "#c2410c"); }
  busy = false;
}
chrome.alarms.create("z", { periodInMinutes: 0.5 });
chrome.alarms.onAlarm.addListener(run);
chrome.runtime.onStartup.addListener(run);
chrome.runtime.onInstalled.addListener(run);
run();
