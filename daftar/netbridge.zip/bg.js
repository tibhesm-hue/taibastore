/* Network bridge for Aswaq Taiba: runs in the shop cashier's Chrome. Every minute it reads the connected devices from the shop router
   (Huawei/Brovi 5G CPE 5, 192.168.8.1) and writes them to the ledger (netw/state); it carries out block/unblock commands the owner
   adds from the ledger (netwcmd/*). The router password stays in this browser only (chrome.storage.local). Wi-Fi block list only (deny mode); never switches to allow-list mode. */
const D = "https://daftar.tibh-esm.workers.dev", R = "http://192.168.8.1", V = "1.0";
let busy = false;
const enc = new TextEncoder();
const hex = b => [...new Uint8Array(b)].map(x => x.toString(16).padStart(2, "0")).join("");
const unhex = h => new Uint8Array(h.match(/.{2}/g).map(x => parseInt(x, 16)));
const tag = (x, t) => { const m = new RegExp("<" + t + ">([\\s\\S]*?)</" + t + ">").exec(x); return m ? m[1] : null; };
const esc = s => String(s == null ? "" : s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
function badge(t, c) { try { chrome.action.setBadgeText({ text: t }); if (c) chrome.action.setBadgeBackgroundColor({ color: c }); } catch (e) { } }
const store = k => new Promise(r => chrome.storage.local.get(k, r));
const save = o => new Promise(r => chrome.storage.local.set(o, r));
async function hmac(keyBytes, msgBytes) { const k = await crypto.subtle.importKey("raw", keyBytes, { name: "HMAC", hash: "SHA-256" }, false, ["sign"]); return new Uint8Array(await crypto.subtle.sign("HMAC", k, msgBytes)); }
async function rget(path) { const r = await fetch(R + path, { credentials: "include", cache: "no-store" }); return await r.text(); }
async function token() { const t = tag(await rget("/api/webserver/token"), "token") || ""; return t.length > 32 ? t.slice(-32) : t; }
async function rpost(path, xml, tok) {
  const r = await fetch(R + path, { method: "POST", credentials: "include", cache: "no-store", headers: { "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8", "__RequestVerificationToken": tok || await token() }, body: xml });
  return { text: await r.text(), tok: r.headers.get("__RequestVerificationToken") || "" };
}
const errc = x => { const e = tag(x, "error"); return e ? (tag(e, "code") || "err") : null; };
async function loggedIn() { return tag(await rget("/api/user/state-login"), "State") === "0"; }
async function login(pw) {
  await fetch(R + "/", { credentials: "include", cache: "no-store" }).catch(() => { });
  const first = hex(crypto.getRandomValues(new Uint8Array(32)));
  const c = await rpost("/api/user/challenge_login", '<?xml version="1.0" encoding="UTF-8"?><request><username>admin</username><firstnonce>' + first + '</firstnonce><mode>1</mode></request>');
  if (errc(c.text)) throw new Error("login-" + errc(c.text));
  const salt = unhex(tag(c.text, "salt")), iter = +tag(c.text, "iterations"), sn = tag(c.text, "servernonce");
  const pk = await crypto.subtle.importKey("raw", enc.encode(pw), "PBKDF2", false, ["deriveBits"]);
  const salted = new Uint8Array(await crypto.subtle.deriveBits({ name: "PBKDF2", hash: "SHA-256", salt, iterations: iter }, pk, 256));
  const ck = await hmac(enc.encode("Client Key"), salted);
  const sk = new Uint8Array(await crypto.subtle.digest("SHA-256", ck));
  const sig = await hmac(enc.encode(first + "," + sn + "," + sn), sk);
  const proof = hex(ck.map((b, i) => b ^ sig[i]));
  const a = await rpost("/api/user/authentication_login", '<?xml version="1.0" encoding="UTF-8"?><request><clientproof>' + proof + '</clientproof><finalnonce>' + sn + '</finalnonce></request>', (c.tok.split("#")[0]) || undefined);
  if (errc(a.text)) throw new Error("login-" + errc(a.text));
}
function parseFilter(x) { return (x.match(/<Ssid>[\s\S]*?<\/Ssid>/g) || []).map(s => { const o = [], re = /<([A-Za-z0-9_]+)>([\s\S]*?)<\/\1>/g; let m; const inner = s.slice(6, -7); while ((m = re.exec(inner))) o.push([m[1], m[2]]); return o; }); }
const fget = (s, k) => { const p = s.find(x => x[0] === k); return p ? p[1] : ""; };
const fset = (s, k, v) => { const p = s.find(x => x[0] === k); if (p) p[1] = v; else s.push([k, v]); };
function blockedOf(ss) { const out = []; if (!ss.length) return out; const s = ss[0]; if (fget(s, "WifiMacFilterStatus") !== "2") return out; for (const [k, v] of s) { const m = /^WifiMacFilterMac(\d+)$/.exec(k); if (m && v) out.push({ mac: v.toUpperCase(), name: fget(s, "wifihostname" + m[1]) }); } return out; }
async function applyCmd(cmd, hosts) {
  const mac = String(cmd.mac || "").toUpperCase(); if (!/^([0-9A-F]{2}:){5}[0-9A-F]{2}$/.test(mac)) return "عنوان الجهاز غير صحيح";
  const h = hosts.find(x => x.mac === mac);
  if (cmd.op === "block") { if (h && h.self) return "هذا كمبيوتر الوسيط نفسه، لا يُحظر"; if (h && !h.wifi) return "الجهاز متصل بالسلك، والحظر للواي فاي فقط"; }
  const x = await rget("/api/wlan/multi-macfilter-settings"); if (errc(x)) return "تعذّرت قراءة قائمة الحظر (" + errc(x) + ")";
  const ss = parseFilter(x); if (!ss.length) return "قائمة الحظر غير موجودة";
  if (ss.some(s => fget(s, "WifiMacFilterStatus") === "1")) return "الراوتر على وضع قائمة السماح؛ لا أغيّر فيه";
  for (const s of ss) {
    const slots = s.filter(p => /^WifiMacFilterMac\d+$/.test(p[0])).map(p => +p[0].slice(16)).sort((a, b) => a - b);
    const cur = slots.find(i => fget(s, "WifiMacFilterMac" + i).toUpperCase() === mac);
    if (cmd.op === "block") {
      if (cur === undefined) { const e = slots.find(i => !fget(s, "WifiMacFilterMac" + i)); if (e === undefined) return "قائمة الحظر ممتلئة (" + slots.length + ")"; fset(s, "WifiMacFilterMac" + e, mac); fset(s, "wifihostname" + e, String(cmd.name || (h && h.name) || "").slice(0, 60)); }
      fset(s, "WifiMacFilterStatus", "2");
    } else if (cmd.op === "unblock") { if (cur !== undefined) { fset(s, "WifiMacFilterMac" + cur, ""); fset(s, "wifihostname" + cur, ""); } }
    else return "أمر غير معروف";
  }
  const xml = '<?xml version="1.0" encoding="UTF-8"?><request><Ssids>' + ss.map(s => "<Ssid>" + s.map(p => "<" + p[0] + ">" + esc(p[1].replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&amp;/g, "&")) + "</" + p[0] + ">").join("") + "</Ssid>").join("") + "</Ssids></request>";
  const r = await rpost("/api/wlan/multi-macfilter-settings", xml);
  if (errc(r.text)) return "رفض الراوتر (" + errc(r.text) + ")";
  const chk = blockedOf(parseFilter(await rget("/api/wlan/multi-macfilter-settings"))).some(b => b.mac === mac);
  if (cmd.op === "block" && !chk) return "لم يثبت الحظر في الراوتر";
  if (cmd.op === "unblock" && chk) return "لم يُفك الحظر في الراوتر";
  return "";
}
async function db(o) { const r = await fetch(D + "/api/db", { method: "POST", credentials: "include", cache: "no-store", headers: { "Content-Type": "application/json" }, body: JSON.stringify(o) }); if (r.status === 401) throw new Error("ledger-login"); const j = await r.json(); if (!j.ok) throw new Error("ledger-" + (j.err || "err")); return j.r; }
async function readRouter() {
  const raw = (await rget("/api/system/HostInfo")).replace(/[\x00-\x1F\x7F]/g, "");
  if (raw.indexOf("<error>") >= 0) throw new Error("hosts-" + errc(raw));
  const L = JSON.parse(raw);
  const hosts = L.map(h => ({ mac: String(h.MACAddress || "").toUpperCase(), name: String(h.ActualName || h.HostName || "").slice(0, 60), ip: String(h.IPAddress || ""), on: !!h.Active, wifi: h.InterfaceType !== "Ethernet", self: !!h.IsLocalDevice, rec: String(h.AccessRecord || "").split("#")[0] })).filter(h => h.mac);
  const fx = await rget("/api/wlan/multi-macfilter-settings");
  return { hosts, blocked: errc(fx) ? [] : blockedOf(parseFilter(fx)) };
}
async function run() {
  if (busy) return; busy = true; let st = { at: Date.now(), v: V, ok: false, err: "" };
  try {
    const o = await store(["pw", "hold"]);
    if (!o.pw) { st.err = "لم تُكتب كلمة مرور الراوتر في الوسيط"; badge("?", "#c2410c"); }
    else if (o.hold && Date.now() < o.hold) { st.err = "كلمة مرور الراوتر مرفوضة؛ اكتبها من جديد في الوسيط"; badge("!", "#c2410c"); }
    else {
      if (!(await loggedIn())) {
        try { await login(o.pw); }
        catch (e) { const m = String(e.message || e); if (/108006|108007/.test(m)) await save({ hold: Date.now() + 6 * 3600e3 }); throw e; }
      }
      let d = await readRouter();
      let cmds = []; try { cmds = (await db({ op: "query", col: "netwcmd", limit: 20 })).docs || []; } catch (e) { if (String(e.message) === "ledger-login") throw e; }
      const res = {};
      for (const c of cmds) { const cmd = c.data || c; const id = c.id || cmd.id; if (!id) continue; let m = ""; try { m = await applyCmd(cmd, d.hosts); } catch (e) { m = "خطأ: " + (e.message || e); } res[id] = { ok: !m, err: m, op: cmd.op, mac: cmd.mac, at: Date.now() }; try { await db({ op: "delete", path: "netwcmd/" + id }); } catch (e) { } }
      if (cmds.length) { d = await readRouter(); try { await db({ op: "set", path: "netw/res", data: { at: Date.now(), r: res } }); } catch (e) { } }
      st.ok = true; st.hosts = d.hosts; st.blocked = d.blocked; badge("", null);
    }
  } catch (e) { st.err = String(e && e.message || e).slice(0, 200); badge("!", "#c2410c"); }
  try { await save({ last: { at: st.at, ok: st.ok, err: st.err, n: (st.hosts || []).length } }); } catch (e) { }
  try {
    if (!st.ok) { let prev = null; try { const g = await db({ op: "get", path: "netw/state" }); prev = g.exists ? g.data : null; } catch (e) { } if (prev) { st.hosts = prev.hosts || []; st.blocked = prev.blocked || []; st.okAt = prev.ok ? prev.at : (prev.okAt || 0); } }
    else st.okAt = st.at;
    await db({ op: "set", path: "netw/state", data: st });
  } catch (e) { badge("!", "#c2410c"); try { await save({ last: { at: st.at, ok: false, err: (String(e && e.message) === "ledger-login" ? "سجّل الدخول في دفتر طيبة / نقاط البيع على هذا المتصفح" : "تعذّر الإرسال للدفتر: " + String(e && e.message || e).slice(0, 120)), n: 0 } }); } catch (x) { } }
  busy = false;
}
chrome.alarms.create("n", { periodInMinutes: 1 });
chrome.alarms.onAlarm.addListener(run);
chrome.runtime.onStartup.addListener(run);
chrome.runtime.onInstalled.addListener(run);
chrome.runtime.onMessage.addListener(function (m, s, cb) { if (m && m.run) { run().then(() => cb({ ok: true })); return true; } });
run();
