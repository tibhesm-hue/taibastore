var st = document.getElementById('st');
function show() { chrome.storage.local.get(['last', 'pw'], function (o) { var l = o.last || {}; st.textContent = (o.pw ? 'كلمة المرور محفوظة. ' : 'لم تُحفظ كلمة المرور بعد. ') + (l.at ? ('آخر قراءة: ' + new Date(l.at).toLocaleTimeString('en-GB') + ' — ' + (l.ok ? ('نجحت، الأجهزة: ' + l.n) : ('فشلت: ' + l.err))) : ''); }); }
document.getElementById('sv').onclick = function () {
  var v = document.getElementById('pw').value; if (!v) { st.textContent = 'اكتب كلمة المرور أولاً.'; return; }
  chrome.storage.local.set({ pw: v, hold: 0 }, function () { document.getElementById('pw').value = ''; st.textContent = 'جاري التجربة…'; chrome.runtime.sendMessage({ run: 1 }, function () { setTimeout(show, 500); }); });
};
show();
